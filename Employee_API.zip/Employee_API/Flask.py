import pandas as pd
import pymysql
import os
import flask
import sys
from flask import Flask, request, render_template, session, redirect, jsonify
from logging import FileHandler,WARNING

#******** Connection to mysql *************
conn=pymysql.connect(host='localhost',port=int(3306),user='root',passwd='college',db='employees')

app = flask.Flask(__name__)
app.config["DEBUG"] = True
#***** Error Logging *****
file_handler = FileHandler('errorlog.txt')
file_handler.setLevel(WARNING)

tokens = {  "token_no":"Allowed_Emp_no",
            "e79b1c21-8013-407b-8e34-98d47af49eb2": "any",
            "563b6bc4-f31a-40b2-bbd2-c475c7a375bd": "100001",
            "a33dcad9-8d66-4b7d-890f-99d92c6491c2": "100002",
            "c0455fe9-3106-4a7a-b347-eb4fd2c6d166": "100003",
            "2d8bbc22-0106-40c3-819f-0cebacffbc19": "100004",
            "6318f8ae-ff59-46a7-8e78-7599f91971f5": "100005",
            "50a63c32-09bc-4202-b526-95d80c6bb1e2": "100006",
            "06778cfd-db6f-49f2-af9b-13f0e14ac24f": "100007",
            "91697fc2-4c18-42b4-bf00-2289de213d13": "100008",
            "0fafdd17-0225-4f9d-aea0-eae6f4d8c9a0": "100009",
            "09386208-c018-4725-859e-5ff69012b98e": "100010"
        }
#print(tokens.values())

#******** Landing Page********
@app.route('/')
@app.route('/index')
def index():
    return "Welcome to Employee API!"
print("ADD/choose Opertion1 or Operation2 in URL")

#************* OPERATION 1 ************************
@app.route('/Operation1', methods=['GET'])
def home():
    df = pd.read_sql_query("SELECT * FROM employees limit 10", conn)
    df.to_html(header="true", table_id="table")
    return render_template('Operation1.html', tables=[df.to_html(classes='data')], titles=df.columns.values)
    #return df

#************* OPERATION 2 ************************

@app.route('/Operation2', methods=['GET'])
def api_id():
    # Check if an EMP_NO was provided as part of the URL.
    # If EMP_NO is provided, assign it to a variable.
    # If no EMP_NO is provided, display an error in the browser.
    emp_no = request.args.get('emp_no')
    #print(emp_no)
    #print(list(request.args))
    try:
        if emp_no is None:
            return 'Please enter a valid employee_no'
        elif emp_no == 'any':
            return 'Authenticated but data doesnt exist. Please try a valid emp_no'
        elif emp_no in tokens.values():
                df2 = pd.read_sql_query("SELECT emp.emp_no,emp.first_name,emp.last_name,curr.dept_no,sal.salary,sal.from_date,sal.to_date FROM employees emp inner join current_dept_emp curr on emp.emp_no=curr.emp_no left join salaries sal on emp.emp_no=sal.emp_no where emp.emp_no = {emp_no} ".format(emp_no=emp_no),conn)
                df2.to_html(header="true", table_id="table")
                return render_template('Operation1.html', tables=[df2.to_html(classes='data')], titles=df2.columns.values)
        else:
                return "Error: Emp_No not authenticated. Please Re-try."
    except Exception as e:
        return print(str(e))
if __name__=='__main__':
    app.run()